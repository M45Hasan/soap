import { syncQueue } from "../queues/sync.queue";

export async function startScheduler(): Promise<void> {
  await syncQueue.upsertJobScheduler(
    "patient-sync-scheduler",
    { every: 60_000 },
    {
      name: "sync-patients",
      data: {}
    }
  );

  await syncQueue.upsertJobScheduler(
    "referral-sync-scheduler",
    { every: 60_000 },
    {
      name: "sync-referrals",
      data: {}
    }
  );

  console.log("HHA sync schedulers started");
}
