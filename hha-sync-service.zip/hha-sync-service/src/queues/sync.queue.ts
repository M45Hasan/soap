import { Queue } from "bullmq";
import { redis } from "../config/redis";

export const syncQueue = new Queue("hha-sync", {
  connection: redis,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: "exponential",
      delay: 5000
    },
    removeOnComplete: 100,
    removeOnFail: 500
  }
});
