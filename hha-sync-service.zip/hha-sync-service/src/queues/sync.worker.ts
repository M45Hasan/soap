import { Worker } from "bullmq";
import { redis } from "../config/redis";
import { syncPatients } from "../services/patient-sync.service";
import { syncReferrals } from "../services/referral-sync.service";

export const syncWorker = new Worker(
  "hha-sync",
  async (job) => {
    switch (job.name) {
      case "sync-patients":
        return syncPatients();

      case "sync-referrals":
        return syncReferrals();

      default:
        throw new Error(`Unknown job: ${job.name}`);
    }
  },
  {
    connection: redis,
    concurrency: 5
  }
);

syncWorker.on("completed", (job, result) => {
  console.log(`Completed ${job.name}`, result);
});

syncWorker.on("failed", (job, error) => {
  console.error(`Failed ${job?.name}`, error);
});
