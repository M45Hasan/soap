export interface NormalizedPatientReferral {
  patientId: number;
  referralId?: number;
  patientStatus?: string;
  referralStatus?: string;
}

export interface NormalizedReferralStatus {
  referralId: number;
  patientId?: number;
  referralStatus: string;
}
