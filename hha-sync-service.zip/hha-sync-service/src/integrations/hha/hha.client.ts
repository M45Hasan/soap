import soap from "soap";
import type {
  NormalizedPatientReferral,
  NormalizedReferralStatus
} from "./hha.types";

export class HhaClient {
  private client: any | null = null;

  private async getClient(): Promise<any> {
    if (this.client) return this.client;

    const wsdlUrl = process.env.HHA_WSDL_URL;
    if (!wsdlUrl) throw new Error("HHA_WSDL_URL is missing");

    this.client = await soap.createClientAsync(wsdlUrl);
    return this.client;
  }

  /**
   * IMPORTANT:
   * Verify method name and argument names against your exact HHA WSDL.
   */
  async getPatientReferralInfo(
    patientId: number
  ): Promise<NormalizedPatientReferral> {
    const client = await this.getClient();

    const args = {
      PatientID: patientId,
      Username: process.env.HHA_USERNAME,
      Password: process.env.HHA_PASSWORD
    };

    const result = await client.GetPatientReferralInfoAsync(args);
    return this.normalizePatientReferral(result, patientId);
  }

  /**
   * IMPORTANT:
   * Verify method name and argument names against your exact HHA WSDL.
   */
  async getReferralStatus(
    referralId: number
  ): Promise<NormalizedReferralStatus> {
    const client = await this.getClient();

    const args = {
      ReferralMasterId: referralId,
      Username: process.env.HHA_USERNAME,
      Password: process.env.HHA_PASSWORD
    };

    const result = await client.GetReferralStatusAsync(args);
    return this.normalizeReferralStatus(result, referralId);
  }

  /**
   * Keep all SOAP/XML-specific parsing here.
   * Adjust paths after logging a real HHA response.
   */
  private normalizePatientReferral(
    result: any,
    requestedPatientId: number
  ): NormalizedPatientReferral {
    const raw = this.unwrapResult(result);

    return {
      patientId: Number(raw?.PatientID ?? requestedPatientId),
      referralId: raw?.ReferralMasterId
        ? Number(raw.ReferralMasterId)
        : undefined,
      patientStatus: raw?.PatientStatus ?? raw?.Status,
      referralStatus: raw?.ReferralStatus
    };
  }

  private normalizeReferralStatus(
    result: any,
    requestedReferralId: number
  ): NormalizedReferralStatus {
    const raw = this.unwrapResult(result);

    return {
      referralId: Number(
        raw?.ReferralMasterId ?? requestedReferralId
      ),
      patientId: raw?.PatientID
        ? Number(raw.PatientID)
        : undefined,
      referralStatus: String(
        raw?.ReferralStatus ?? raw?.Status ?? "UNKNOWN"
      )
    };
  }

  private unwrapResult(result: any): any {
    if (Array.isArray(result)) {
      return result[0] ?? {};
    }

    return result ?? {};
  }
}

export const hhaClient = new HhaClient();
