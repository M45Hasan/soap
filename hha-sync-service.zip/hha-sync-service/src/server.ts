import "dotenv/config";
import express from "express";
import { connectDB } from "./config/db";
import "./queues/sync.worker";
import { startScheduler } from "./jobs/scheduler";
import adminRoutes from "./routes/admin.routes";

const app = express();

app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({
    success: true,
    service: "hha-sync-service",
    timestamp: new Date().toISOString()
  });
});

app.use("/admin/sync", adminRoutes);

async function bootstrap(): Promise<void> {
  await connectDB();
  await startScheduler();

  const port = Number(process.env.PORT || 5000);

  app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
  });
}

bootstrap().catch((error) => {
  console.error("Application failed to start", error);
  process.exit(1);
});
