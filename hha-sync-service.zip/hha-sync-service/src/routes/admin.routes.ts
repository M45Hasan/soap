import { Router } from "express";
import { Patient } from "../models/patient.model";
import { Referral } from "../models/referral.model";
import { syncQueue } from "../queues/sync.queue";

const router = Router();

/**
 * Demo only.
 * DO NOT expose these endpoints publicly without authentication.
 */
router.post("/seed-demo", async (_req, res) => {
  const now = new Date();

  await Patient.bulkWrite([
    {
      updateOne: {
        filter: { hhaPatientId: 10001 },
        update: {
          $set: {
            hhaPatientId: 10001,
            status: "HOLD",
            referralId: 20001,
            syncStatus: "PENDING",
            nextSyncAt: now
          }
        },
        upsert: true
      }
    },
    {
      updateOne: {
        filter: { hhaPatientId: 10002 },
        update: {
          $set: {
            hhaPatientId: 10002,
            status: "ACTIVE",
            referralId: 20002,
            syncStatus: "PENDING",
            nextSyncAt: now
          }
        },
        upsert: true
      }
    }
  ]);

  await Referral.bulkWrite([
    {
      updateOne: {
        filter: { hhaReferralId: 20001 },
        update: {
          $set: {
            hhaReferralId: 20001,
            hhaPatientId: 10001,
            status: "NEGATIVE",
            syncStatus: "PENDING",
            nextSyncAt: now
          }
        },
        upsert: true
      }
    },
    {
      updateOne: {
        filter: { hhaReferralId: 20002 },
        update: {
          $set: {
            hhaReferralId: 20002,
            hhaPatientId: 10002,
            status: "POSITIVE",
            syncStatus: "PENDING",
            nextSyncAt: now
          }
        },
        upsert: true
      }
    }
  ]);

  res.json({
    success: true,
    message: "Demo records seeded"
  });
});

router.post("/run-now", async (_req, res) => {
  await syncQueue.add("sync-patients", {});
  await syncQueue.add("sync-referrals", {});

  res.json({
    success: true,
    message: "Sync jobs queued"
  });
});

export default router;
