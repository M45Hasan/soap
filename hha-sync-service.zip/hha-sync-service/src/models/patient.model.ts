import mongoose, { Document, Schema } from "mongoose";

export type SyncStatus = "PENDING" | "RUNNING" | "SYNCED" | "FAILED";

export interface IPatient extends Document {
  hhaPatientId: number;
  status: string;
  previousStatus?: string;
  referralId?: number;
  lastSyncedAt?: Date;
  statusChangedAt?: Date;
  syncStatus: SyncStatus;
  syncError?: string;
  nextSyncAt: Date;
}

const patientSchema = new Schema<IPatient>(
  {
    hhaPatientId: {
      type: Number,
      required: true,
      unique: true,
      index: true
    },
    status: {
      type: String,
      required: true,
      index: true
    },
    previousStatus: String,
    referralId: {
      type: Number,
      index: true
    },
    lastSyncedAt: {
      type: Date,
      index: true
    },
    statusChangedAt: Date,
    syncStatus: {
      type: String,
      enum: ["PENDING", "RUNNING", "SYNCED", "FAILED"],
      default: "PENDING",
      index: true
    },
    syncError: String,
    nextSyncAt: {
      type: Date,
      default: Date.now,
      index: true
    }
  },
  { timestamps: true }
);

patientSchema.index({ nextSyncAt: 1, syncStatus: 1 });

export const Patient = mongoose.model<IPatient>("Patient", patientSchema);
