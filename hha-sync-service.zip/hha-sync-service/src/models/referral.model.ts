import mongoose, { Document, Schema } from "mongoose";
import type { SyncStatus } from "./patient.model";

export interface IReferral extends Document {
  hhaReferralId: number;
  hhaPatientId: number;
  status: string;
  previousStatus?: string;
  lastSyncedAt?: Date;
  statusChangedAt?: Date;
  syncStatus: SyncStatus;
  syncError?: string;
  nextSyncAt: Date;
}

const referralSchema = new Schema<IReferral>(
  {
    hhaReferralId: {
      type: Number,
      required: true,
      unique: true,
      index: true
    },
    hhaPatientId: {
      type: Number,
      required: true,
      index: true
    },
    status: {
      type: String,
      required: true,
      index: true
    },
    previousStatus: String,
    lastSyncedAt: {
      type: Date,
      index: true
    },
    statusChangedAt: Date,
    syncStatus: {
      type: String,
      enum: ["PENDING", "RUNNING", "SYNCED", "FAILED"],
      default: "PENDING",
      index: true
    },
    syncError: String,
    nextSyncAt: {
      type: Date,
      default: Date.now,
      index: true
    }
  },
  { timestamps: true }
);

referralSchema.index({ hhaPatientId: 1 });
referralSchema.index({ nextSyncAt: 1, syncStatus: 1 });

export const Referral = mongoose.model<IReferral>("Referral", referralSchema);
