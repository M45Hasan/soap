import mongoose, { Document, Schema } from "mongoose";

export interface IStatusHistory extends Document {
  entityType: "PATIENT" | "REFERRAL";
  entityId: number;
  oldStatus?: string;
  newStatus: string;
  source: "HHA" | "SYSTEM";
  createdAt: Date;
}

const schema = new Schema<IStatusHistory>(
  {
    entityType: {
      type: String,
      enum: ["PATIENT", "REFERRAL"],
      required: true
    },
    entityId: {
      type: Number,
      required: true,
      index: true
    },
    oldStatus: String,
    newStatus: {
      type: String,
      required: true
    },
    source: {
      type: String,
      enum: ["HHA", "SYSTEM"],
      required: true
    }
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

schema.index({ entityType: 1, entityId: 1, createdAt: -1 });

export const StatusHistory = mongoose.model<IStatusHistory>(
  "StatusHistory",
  schema
);
