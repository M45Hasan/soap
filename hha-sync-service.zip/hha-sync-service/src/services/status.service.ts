import { Referral } from "../models/referral.model";
import { StatusHistory } from "../models/status-history.model";

interface PatientStatusChange {
  patientId: number;
  referralId?: number;
  oldStatus: string;
  newStatus: string;
}

export function determineReferralStatus(
  patientStatus: string
): string | null {
  switch (patientStatus.toUpperCase()) {
    case "HOLD":
      return "NEGATIVE";

    case "DISCHARGE":
      return "POSITIVE";

    default:
      return null;
  }
}

export async function processPatientStatusChange(
  data: PatientStatusChange
): Promise<void> {
  if (!data.referralId) return;

  const requiredStatus = determineReferralStatus(data.newStatus);

  if (!requiredStatus) return;

  const referral = await Referral.findOne({
    hhaReferralId: data.referralId
  });

  if (!referral) {
    console.warn(
      `Referral not found for patient ${data.patientId}: ${data.referralId}`
    );
    return;
  }

  // Idempotency: do nothing if desired state already exists.
  if (referral.status === requiredStatus) {
    return;
  }

  const oldReferralStatus = referral.status;

  await Referral.updateOne(
    {
      _id: referral._id,
      status: { $ne: requiredStatus }
    },
    {
      $set: {
        previousStatus: oldReferralStatus,
        status: requiredStatus,
        statusChangedAt: new Date(),
        syncStatus: "PENDING",
        nextSyncAt: new Date(),
        syncError: undefined
      }
    }
  );

  await StatusHistory.create({
    entityType: "REFERRAL",
    entityId: data.referralId,
    oldStatus: oldReferralStatus,
    newStatus: requiredStatus,
    source: "SYSTEM"
  });

  console.log(
    `Referral ${data.referralId}: ${oldReferralStatus} -> ${requiredStatus}`
  );

  // If your business rule requires updating HHA itself,
  // enqueue an HHA UPDATE job here.
}
