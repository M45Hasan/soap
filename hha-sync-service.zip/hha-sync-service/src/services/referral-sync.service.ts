import { Referral } from "../models/referral.model";
import { StatusHistory } from "../models/status-history.model";
import { hhaClient } from "../integrations/hha/hha.client";

const BATCH_SIZE = 100;

export async function syncReferrals(): Promise<{
  processed: number;
  failed: number;
}> {
  const referrals = await Referral.find({
    nextSyncAt: { $lte: new Date() },
    syncStatus: { $in: ["PENDING", "SYNCED", "FAILED"] }
  })
    .sort({ nextSyncAt: 1 })
    .limit(BATCH_SIZE)
    .lean();

  let processed = 0;
  let failed = 0;

  for (const referral of referrals) {
    try {
      await Referral.updateOne(
        { _id: referral._id },
        { $set: { syncStatus: "RUNNING" } }
      );

      const data = await hhaClient.getReferralStatus(
        referral.hhaReferralId
      );

      const newStatus = data.referralStatus;
      const oldStatus = referral.status;
      const changed = oldStatus !== newStatus;

      const update: Record<string, any> = {
        status: newStatus,
        lastSyncedAt: new Date(),
        syncStatus: "SYNCED",
        syncError: undefined,
        nextSyncAt: getNextSyncTime(newStatus)
      };

      if (changed) {
        update.previousStatus = oldStatus;
        update.statusChangedAt = new Date();
      }

      await Referral.updateOne(
        { _id: referral._id },
        { $set: update }
      );

      if (changed) {
        await StatusHistory.create({
          entityType: "REFERRAL",
          entityId: referral.hhaReferralId,
          oldStatus,
          newStatus,
          source: "HHA"
        });
      }

      processed++;
    } catch (error) {
      failed++;

      const message =
        error instanceof Error ? error.message : String(error);

      await Referral.updateOne(
        { _id: referral._id },
        {
          $set: {
            syncStatus: "FAILED",
            syncError: message,
            nextSyncAt: new Date(Date.now() + 10 * 60 * 1000)
          }
        }
      );

      console.error(
        `Referral sync failed: ${referral.hhaReferralId}`,
        error
      );
    }
  }

  return { processed, failed };
}

function getNextSyncTime(status: string): Date {
  const now = Date.now();

  switch (status.toUpperCase()) {
    case "PENDING":
      return new Date(now + 10 * 60 * 1000);

    case "NEGATIVE":
      return new Date(now + 15 * 60 * 1000);

    case "POSITIVE":
      return new Date(now + 30 * 60 * 1000);

    default:
      return new Date(now + 30 * 60 * 1000);
  }
}
