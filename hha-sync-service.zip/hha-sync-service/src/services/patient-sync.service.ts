import { Patient } from "../models/patient.model";
import { StatusHistory } from "../models/status-history.model";
import { hhaClient } from "../integrations/hha/hha.client";
import { processPatientStatusChange } from "./status.service";

const BATCH_SIZE = 100;

export async function syncPatients(): Promise<{
  processed: number;
  failed: number;
}> {
  const now = new Date();

  const patients = await Patient.find({
    nextSyncAt: { $lte: now },
    syncStatus: { $in: ["PENDING", "SYNCED", "FAILED"] }
  })
    .sort({ nextSyncAt: 1 })
    .limit(BATCH_SIZE)
    .lean();

  let processed = 0;
  let failed = 0;

  for (const patient of patients) {
    try {
      await Patient.updateOne(
        { _id: patient._id },
        { $set: { syncStatus: "RUNNING" } }
      );

      const data = await hhaClient.getPatientReferralInfo(
        patient.hhaPatientId
      );

      const newStatus =
        data.patientStatus ?? patient.status;

      const oldStatus = patient.status;
      const changed = oldStatus !== newStatus;

      const update: Record<string, any> = {
        status: newStatus,
        referralId: data.referralId,
        lastSyncedAt: new Date(),
        syncStatus: "SYNCED",
        syncError: undefined,
        nextSyncAt: getNextSyncTime(newStatus)
      };

      if (changed) {
        update.previousStatus = oldStatus;
        update.statusChangedAt = new Date();
      }

      await Patient.updateOne(
        { _id: patient._id },
        { $set: update }
      );

      if (changed) {
        await StatusHistory.create({
          entityType: "PATIENT",
          entityId: patient.hhaPatientId,
          oldStatus,
          newStatus,
          source: "HHA"
        });

        await processPatientStatusChange({
          patientId: patient.hhaPatientId,
          referralId: data.referralId ?? patient.referralId,
          oldStatus,
          newStatus
        });
      }

      processed++;
    } catch (error) {
      failed++;

      const message =
        error instanceof Error ? error.message : String(error);

      await Patient.updateOne(
        { _id: patient._id },
        {
          $set: {
            syncStatus: "FAILED",
            syncError: message,
            nextSyncAt: new Date(Date.now() + 10 * 60 * 1000)
          }
        }
      );

      console.error(
        `Patient sync failed: ${patient.hhaPatientId}`,
        error
      );
    }
  }

  return { processed, failed };
}

function getNextSyncTime(status: string): Date {
  const now = Date.now();

  switch (status.toUpperCase()) {
    case "ACTIVE":
      return new Date(now + 5 * 60 * 1000);

    case "PENDING":
      return new Date(now + 10 * 60 * 1000);

    case "HOLD":
      return new Date(now + 15 * 60 * 1000);

    case "DISCHARGE":
      return new Date(now + 6 * 60 * 60 * 1000);

    default:
      return new Date(now + 30 * 60 * 1000);
  }
}
