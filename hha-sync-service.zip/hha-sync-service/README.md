# HHA Patient / Referral Synchronization Service

Node.js + TypeScript + MongoDB + Redis + BullMQ + SOAP starter architecture for synchronizing HHAeXchange Patient and Referral status.

## Architecture

HHA SOAP
  -> HHA Adapter (SOAP/XML)
  -> BullMQ / Redis
  -> Sync Workers
  -> MongoDB
  -> Status Engine
  -> Optional HHA update

## Important

The HHA SOAP methods and request/response property names in this project are intentionally isolated in:

`src/integrations/hha/hha.client.ts`

You MUST verify them against the exact WSDL/account integration provided by your organization before production use.

## Requirements

- Node.js 20+
- MongoDB
- Redis

## Setup

```bash
npm install
cp .env.example .env
```

Set MongoDB, Redis, and HHA credentials in `.env`.

Then:

```bash
npm run dev
```

Production:

```bash
npm run build
npm start
```

## Seed / testing

The service exposes:

- `GET /health`
- `POST /admin/sync/seed-demo`
- `POST /admin/sync/run-now`

The demo seed creates sample Patient/Referral records only. It does not call HHA until their `nextSyncAt` is due.

## Synchronization strategy

The worker only queries records whose:

`nextSyncAt <= now`

It processes a limited batch and uses controlled BullMQ concurrency.

Polling intervals are adaptive by status. Change them in:

- `src/services/patient-sync.service.ts`
- `src/services/referral-sync.service.ts`

## Status rules

Current example:

- Patient HOLD -> Referral NEGATIVE
- Patient DISCHARGE -> Referral POSITIVE

Change these rules in:

`src/services/status.service.ts`

## Production checklist

1. Confirm exact HHA SOAP endpoint/method names.
2. Confirm HHA rate/concurrency limits.
3. Confirm whether HHA offers modified-since/bulk/webhook capabilities.
4. Add authentication/authorization to admin endpoints.
5. Add structured logging and monitoring.
6. Add a dead-letter/error workflow.
7. Add status history/audit retention according to company requirements.
8. Test idempotency and retry behavior.
9. Use separate worker processes in production.
10. Do not commit `.env`.
